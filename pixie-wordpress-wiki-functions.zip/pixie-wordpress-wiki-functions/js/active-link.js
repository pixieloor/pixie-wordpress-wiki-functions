// active-link.js
document.addEventListener('DOMContentLoaded', function() {
    console.log('Pixie Wiki active link script loaded.');
});
